# project-fa19
CS 170 Fall 2019 Project

Alex Chan
Jinwoo Park
Brian Stone

Instructions to run the program:

Make sure that numpy and networkx packages are installed to your version of Python.

Put the valid input files in a folder and create a folder that will store the outputs.

Run the program with the following command to solve every files in the given input file:

python solver.py --all YOUR_INPUT_FOLDER/ YOUR_OUTPUT_FOLDER/

If you are looking to run the solver for just a single input, run the following command and the output file will be created in your current directory:

python solver.py YOUR_INPUT_FILE
